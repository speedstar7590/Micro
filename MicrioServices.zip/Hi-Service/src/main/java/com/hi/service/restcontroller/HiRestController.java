package com.hi.service.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hi.service.client.HelloServiceClient;

@RestController
public class HiRestController {
	
	@Autowired
	private HelloServiceClient client;
	@GetMapping(value="/hi")
	public String hi() {
		String msg="Hi";
		String msg1=client.invokeHelloService();
		return msg.concat(","+msg1);
	}

}
